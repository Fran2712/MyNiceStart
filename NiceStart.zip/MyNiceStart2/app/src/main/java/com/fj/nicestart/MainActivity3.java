package com.fj.nicestart;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity3 extends AppCompatActivity {

    private WebView wb_sa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        wb_sa = (WebView)findViewById(R.id.mi_wb);
        wb_sa.loadUrl("https://bot.dialogflow.com/a0cf5304-9c1d-4204-9f78-d39680b00e02");

    }
}