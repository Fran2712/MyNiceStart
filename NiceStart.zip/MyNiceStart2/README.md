# Nice Start
[github.com Fran2712 ](https://github.com/Fran2712)
#### Preview of the app

| *Splash*              | *Login*              | *Register*              |
|:--------------------|:-------------------|:----------------------|
| ![](img/Splash.PNG) | ![](img/Login.PNG) | ![](img/Register.PNG) |
| *Main*              | *Main 2*              |
| ![](img/Main.PNG) | ![](img/Main2.PNG) |
